
from telegram import Bot
from pagamentos.pix import criar_pix

TOKEN = "COLOQUE_SEU_TOKEN_AQUI"
bot = Bot(TOKEN)

def iniciar_compra(user_id):
    valor = 5.99
    pix_payload = criar_pix(valor)
    bot.send_message(
        chat_id=user_id,
        text=f"💳 Valor: R$ 5,99\n\nPague via PIX copia e cola:\n{pix_payload}"
    )
