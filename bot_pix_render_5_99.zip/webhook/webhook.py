
from flask import Blueprint, request

webhook_bp = Blueprint("webhook", __name__)

@webhook_bp.route("/webhook", methods=["POST"])
def webhook():
    data = request.json
    
    if data and data.get("status") == "CONFIRMED":
        return "Pagamento confirmado", 200
    
    return "Evento recebido", 200
