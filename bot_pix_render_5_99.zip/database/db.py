
import sqlite3

def conectar():
    return sqlite3.connect("database.db")

def criar_tabela():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pagamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            pix_id TEXT,
            status TEXT
        )
    ''')
    conn.commit()
    conn.close()
