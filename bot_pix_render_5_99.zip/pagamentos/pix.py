
import uuid

def criar_pix(valor):
    # SIMULAÇÃO DE PIX DINÂMICO
    txid = str(uuid.uuid4())
    payload_pix = f"PIX_SIMULADO_TXID_{txid}_VALOR_{valor}"
    return payload_pix
