
from flask import Blueprint, request
import mercadopago
import os
from telegram import Bot
from database.db import atualizar_status, buscar_usuario

webhook_bp = Blueprint("webhook", __name__)

sdk = mercadopago.SDK(os.getenv("MP_ACCESS_TOKEN"))
bot = Bot(os.getenv("TELEGRAM_TOKEN"))

GRUPO_ID = int(os.getenv("GRUPO_ID"))

@webhook_bp.route("/webhook", methods=["POST"])
def webhook():
    data = request.json

    if "data" in data and "id" in data["data"]:
        payment_id = data["data"]["id"]

        payment = sdk.payment().get(payment_id)
        status = payment["response"]["status"]

        if status == "approved":
            atualizar_status(payment_id)
            user_id = buscar_usuario(payment_id)

            if user_id:
                link = bot.create_chat_invite_link(
                    chat_id=GRUPO_ID,
                    member_limit=1
                )

                bot.send_message(
                    chat_id=user_id,
                    text=f"Pagamento confirmado!\nEntre no grupo:\n{link.invite_link}"
                )

    return "ok", 200
