
import os
from telegram import Bot
from pagamentos.pix import criar_pix
from database.db import salvar_pagamento

TOKEN = os.getenv("TELEGRAM_TOKEN")
bot = Bot(TOKEN)

def iniciar_compra(user_id):
    valor = 5.99
    pix = criar_pix(valor, user_id)

    salvar_pagamento(user_id, pix["id"])

    bot.send_message(
        chat_id=user_id,
        text=f"Valor: R$ 5,99 (mensal)\n\nPague via PIX:\n{pix['qr_code']}"
    )
