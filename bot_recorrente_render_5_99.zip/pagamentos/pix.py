
import mercadopago
import os

sdk = mercadopago.SDK(os.getenv("MP_ACCESS_TOKEN"))

def criar_pix(valor, user_id):
    payment_data = {
        "transaction_amount": float(valor),
        "description": "Assinatura Mensal Grupo VIP",
        "payment_method_id": "pix",
        "payer": {
            "email": f"user{user_id}@teste.com"
        }
    }

    payment = sdk.payment().create(payment_data)
    response = payment["response"]

    return {
        "id": response["id"],
        "qr_code": response["point_of_interaction"]["transaction_data"]["qr_code"]
    }
