
import sqlite3
from datetime import datetime, timedelta

def conectar():
    return sqlite3.connect("database.db")

def criar_tabelas():
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pagamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            payment_id TEXT,
            status TEXT,
            vencimento TEXT
        )
    ''')

    conn.commit()
    conn.close()

def salvar_pagamento(user_id, payment_id):
    conn = conectar()
    cursor = conn.cursor()

    vencimento = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")

    cursor.execute(
        "INSERT INTO pagamentos (user_id, payment_id, status, vencimento) VALUES (?, ?, ?, ?)",
        (user_id, payment_id, "pendente", vencimento)
    )

    conn.commit()
    conn.close()

def atualizar_status(payment_id):
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE pagamentos SET status='pago' WHERE payment_id=?",
        (payment_id,)
    )

    conn.commit()
    conn.close()

def buscar_usuario(payment_id):
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT user_id FROM pagamentos WHERE payment_id=?",
        (payment_id,)
    )

    row = cursor.fetchone()
    conn.close()

    if row:
        return row[0]
    return None
